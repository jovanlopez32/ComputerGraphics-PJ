#include<iostream>
#include<sstream>
#include<fstream>
#include<list>
#include <vector>
#include <math.h> 
#include <GL/glut.h>

#include "ClassObject.h"
#define NUMMAX 50

/*Global variables for the Objects*/
Object3D array[NUMMAX];
/*Variable Trajectpory*/
/*Number of objects*/
static int end;
static GLfloat spin = 2.0, xAxis=0.0, yAxis=0.0, zAxis=0.0;
/*Refresh period in milliseconds*/
int refreshMillis = 200;

/*Values of the translation matrix*/
double dx = 0;
double dy = 0;
double dz = 0;


using namespace std;

int loadFile(char *nf, Object3D  array[]);
void init (void);
void display(void);
void reshape(int w, int h);
void Timer(int value) ;
void mouse(int button, int state, int x, int y);

double *multiplication(double matriz[4][4], double array[4]);


int main(int argc, char **argv){
	/*Fuctions for display screen*/
	glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 600); 
    glutInitWindowPosition (200, 0);
    glutCreateWindow ("EVEREST HOME");
    init ();
    
	end = loadFile("atom.obj", array);
	
	glutDisplayFunc(display); 
	glutMouseFunc(mouse);
    glutMainLoop();
	return 0;
}

double *multiplication(double matriz[4][4], double array[4]){
	
	double mf[4];
	
	mf[0] = matriz[0][0]*array[0] + matriz[0][1]*array[1]+matriz[0][2]*array[2]+matriz[0][3]*array[3];
	mf[1] = matriz[1][0]*array[0] + matriz[1][1]*array[1]+matriz[1][2]*array[2]+matriz[1][3]*array[3];
	mf[2] = matriz[2][0]*array[0] + matriz[2][1]*array[1]+matriz[2][2]*array[2]+matriz[2][3]*array[3];
	mf[3] = matriz[3][0]*array[0] + matriz[3][1]*array[1]+matriz[3][2]*array[2]+matriz[3][3]*array[3];
	
	static int cont2 = 0;
	if(cont2 == 0){
		cout << matriz[0][1]*array[1] << " " << matriz[0][2]*array[2] << " " << matriz[0][3]*array[3] << endl;
	cout << matriz[1][1]*array[1] << " " << matriz[1][2]*array[2] << " " << matriz[1][3]*array[3] << endl;
	cout << matriz[2][1]*array[1] << " " << matriz[2][2]*array[2] << " " << matriz[2][3]*array[3] << endl;
	cout << matriz[3][1]*array[1] << " " << matriz[3][2]*array[2] << " " << matriz[3][3]*array[3] << endl;
	cont2++;
	}
	
	return mf;
}

void init (void) 
{
/*  select clearing (background) color       */
    glClearColor (0.0, 0.0, 0.0, 0.0);

/*  initialize viewing values  */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    //glRotatef (30.0, 1.0, 1.0, 1.0);
    //glOrtho(-6.0, 6.0, -6.0, 6.0, -2.0, 2.0);
    glOrtho(-4.0, 4.0, -4.0, 4.0, -4.0, 4.0);

}

void display(void)
{
	/*  color of the all pixels  */
	glClear (GL_COLOR_BUFFER_BIT);	//Clean the screen for the atom.
    glColor3f (1.0, 1.0, 1.0);
    
    Vertice *vtx = NULL;
    vtx = new Vertice[100000];
    int vi=0;

	for(int i = 0; i <= end; i++){
		
		for(int x=0; x < array[i].v.size(); x++, vi++){
			vtx[vi].x = array[i].v[x].x;
			vtx[vi].y = array[i].v[x].y;
			vtx[vi].z = array[i].v[x].z;
		}

		/*Recorremos las caras de la lista*/
		list<Faces>::iterator jt;
		jt = array[i].f.begin();
		for(jt; jt!=array[i].f.end(); jt++){
			
			list<int>::iterator il;
			il = jt->intls.begin();
			glBegin(GL_LINE_LOOP);
			while(il != jt->intls.end()){
			
				glVertex3f(vtx[*il].x, vtx[*il].y, vtx[*il].z);

				il++;
			}
			glEnd();
		}
		glutSwapBuffers ();	
	}
	vtx = NULL;
	glFlush();
}


void Timer(int value) 
{
	int j;
	static int counter = 0;
	/*Iniciamos los valores donde van a girar los objetos*/
	if(counter == 0){
		dx = 0;
		dy = 0;
		dz = 0;
		counter++;
	}
	
	/*Grades*/
	 double theta;
	 double alpha;
	 double gamma;

	/*Translate the point in the origin*/
	dx = dx * -1;
	dy = dy * -1;
	dz = dz * -1;
	for(int objcont = 0; objcont <= end; objcont++){
		for(j=0; j < array[objcont].v.size(); j++){
			array[objcont].v[j].x = array[objcont].v[j].x + dx;
			array[objcont].v[j].y = array[objcont].v[j].y + dy;
			array[objcont].v[j].z = array[objcont].v[j].z + dz;
		}
	}

	/*Rotation of the object */
	double *newvalues;
	double values[4];
	values[3]=1;
		
	/*Loop for rotate the objects*/
	for(int objcont = 0; objcont <= end; objcont++){
		
		/*The last object in this case is the center sphere. The center sphere don't rotate*/
		
		for(j=0; j < array[objcont].v.size(); j++){
			
			/*Get the rotation of each object*/
			if(objcont == 0){
				theta = 2.8;
				gamma = 45;
				alpha = 0;	
				
			}
			if(objcont == 1){
				theta = 0;
				gamma = 0;
				alpha = 0;
			}
			if(objcont == 2){
				theta = -2.8;
				gamma = -45;
				alpha = 0;
			}
			/*Save the vertices in an array for the matrix multiplication*/
			values[0]=array[objcont].v[j].x;
			values[1]=array[objcont].v[j].y;
			values[2]=array[objcont].v[j].z;
			
			/*Subtitute the variables in the big matrix*/
			double Rf[4][4] = {	
						{ (cos(alpha)*cos(gamma))+(sin(alpha)*sin(theta)*sin(gamma)), (cos(alpha)*-sin(gamma))+(cos(gamma)*sin(alpha)*sin(theta)), sin(alpha)*cos(theta), 0},
						{ cos(theta)*sin(gamma), cos(gamma)*cos(theta), -sin(theta), 0},
						{ (-sin(alpha)*cos(gamma))+(cos(alpha)*sin(theta)*sin(gamma)), (sin(alpha)*sin(gamma))+(cos(alpha)*sin(theta)*cos(gamma)), cos(alpha)*cos(theta), 0},
						{ 0, 0, 0, 1}
			};
			
			/*Aply the matrix multiplication for each vertice*/
			newvalues=multiplication(Rf, values);
				
			/*Save the values of the multiplication in the original array*/
			array[objcont].v[j].x = newvalues[0];
			array[objcont].v[j].y = newvalues[1];
			array[objcont].v[j].z = newvalues[2];
			
			/*Clear the array temp*/
			newvalues = NULL;
		}
	}
	
	/*Translate the point at the original point*/
	dx = dx * -1;
	dy = dy * -1;
	dz = dz * -1;
	for(int objcont = 0; objcont <= end; objcont++){
		for(j=0; j < array[objcont].v.size(); j++){
			array[objcont].v[j].x = array[objcont].v[j].x + dx;
			array[objcont].v[j].y = array[objcont].v[j].y + dy;
			array[objcont].v[j].z = array[objcont].v[j].z + dz;
		}
	}
	
	/*--Redisplay the figures then of the first loop in mainloop*/
    glutPostRedisplay();
    // subsequent timer call at milliseconds
    glutTimerFunc(refreshMillis, Timer, 0);
}

void mouse(int button, int state, int x, int y) 
{
   switch (button) {
      case GLUT_LEFT_BUTTON:
         if (state == GLUT_DOWN){
         	glutTimerFunc(refreshMillis, Timer, 0);
		 }
         break;
      case GLUT_MIDDLE_BUTTON:
         if (state == GLUT_DOWN)
            glutIdleFunc(NULL);
         break;
      default:
         break;
   }
}



