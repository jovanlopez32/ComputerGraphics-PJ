#include<iostream>
#include<sstream>
#include<fstream>
#include<list>
#include <vector>
#include <math.h> 
#include <GL/glut.h>

#include "ClassObject.h"
#include "MatricesOperation.h"
#define NUMMAX 50

/*Global variables for the Objects*/
Object3D array[NUMMAX];
/*Variable Trajectpory*/
/*Number of objects*/
static int end;

/*Refresh period in milliseconds*/
int refreshMillis = 50;

using namespace std;

int loadFile(char *nf, Object3D  array[]);
void init (void);
void display(void);
void reshape(int w, int h);
void Timer(int value) ;
void mouse(int button, int state, int x, int y);

double *multiplication(double matriz[4][4], double array[4]);
void TranslationMatrix(double dx, double dy, double dz);
void RfMatrix();


int main(int argc, char **argv){
	/*Fuctions for display screen*/
	glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 600); 
    glutInitWindowPosition (200, 0);
    glutCreateWindow ("EVEREST HOME");
    init ();
    
	end = loadFile("2.obj", array);
	
	glutDisplayFunc(display); 
	glutMouseFunc(mouse);
    glutMainLoop();
    
	return 0;
}

void Timer(int value) 
{
	
	double dx = 0;
	double dy = 0;
	double dz = 0;
	
	/*---Translation to the origin---*/
	dx = dx * -1;	dy = dy * -1;	dz = dz * -1;
	TranslationMatrix(dx, dy, dz);
	
	static int counter = 0;
	
	theta = 0;
	alpha = 0;
	gamma = 0.1;
	
	RfMatrix();
	
	double newarray[4];
	double *array2;
	
	while(counter < array[0].v.size()){
		
		newarray[0] = array[0].v[counter].x;
		newarray[1] = array[0].v[counter].y;
		newarray[2] = array[0].v[counter].z;
		newarray[3] = 1;
		
		array2 = multiplication(Rf, newarray);
		
		array[0].v[counter].x = array2[0];
		array[0].v[counter].y = array2[1];
		array[0].v[counter].z = array2[2];
		
		counter++;	
	}
	counter = 0;
	
	/*---Translation to the original psoition---*/
	dx = dx * -1;	dy = dy * -1;	dz = dz * -1;
	TranslationMatrix(dx, dy, dz);	
	
	/*--Redisplay the figures then of the first loop in mainloop*/
    glutPostRedisplay();
    // subsequent timer call at milliseconds
    glutTimerFunc(refreshMillis, Timer, 0);
}

void TranslationMatrix(double dx, double dy, double dz){
	
	int i;
	for(i=0; i<=end; i++){
		int x;
		for(x=0; x < array[i].v.size(); x++){
			array[i].v[x].x = array[i].v[x].x - dx;
			array[i].v[x].y = array[i].v[x].y - dy;
			array[i].v[x].z = array[i].v[x].z - dz;
		}
	}
	
}

void RfMatrix(){
	
	Rf[0][0] = (cos(alpha)*cos(gamma))+(sin(alpha)*sin(theta)*sin(gamma)); Rf[0][1] = (cos(alpha)*-sin(gamma))+(cos(gamma)*sin(alpha)*sin(theta));
	Rf[0][2] = sin(alpha)*cos(theta); Rf[0][3] = 0;
	
	Rf[1][0] = cos(theta)*sin(gamma); Rf[1][1] = cos(gamma)*cos(theta);
	Rf[1][2] = -sin(theta); Rf[1][3] = 0;
	
	Rf[2][0] = (-sin(alpha)*cos(gamma))+(cos(alpha)*sin(theta)*sin(gamma)); Rf[2][1] = (sin(alpha)*sin(gamma))+(cos(alpha)*sin(theta)*cos(gamma));
	Rf[2][2] = cos(alpha)*cos(theta); Rf[2][3] = 0;
	
	Rf[3][0] = 0; Rf[3][1] = 0;
	Rf[3][2] = 0; Rf[3][3] = 1;
	
	
}

double *multiplication(double matriz[4][4], double array[4]){
	
	double mf[4];
	
	mf[0] = (matriz[0][0]*array[0] + matriz[0][1]*array[1]+matriz[0][2]*array[2]+matriz[0][3]*array[3]) ;
	mf[1] = (matriz[1][0]*array[0] + matriz[1][1]*array[1]+matriz[1][2]*array[2]+matriz[1][3]*array[3]) ;
	mf[2] = (matriz[2][0]*array[0] + matriz[2][1]*array[1]+matriz[2][2]*array[2]+matriz[2][3]*array[3]) ;
	mf[3] = (matriz[3][0]*array[0] + matriz[3][1]*array[1]+matriz[3][2]*array[2]+matriz[3][3]*array[3]) ;
	
	return mf;
}

void init (void) 
{
/*  select clearing (background) color       */
    glClearColor(0.1, 0.39, 0.88, 1.0);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(-1.5, 1.5, -1.5, 1.5, 2, 10);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(0, 0, -3);
	glRotatef(50, 1, 0, 0);
	//glRotatef(190, 0, 1, 0);

}

void display(void)
{
	/*  color of the all pixels  */
	glClear (GL_COLOR_BUFFER_BIT);	//Clean the screen for the atom.
    glColor3f (1.0, 1.0, 1.0);
    
    Vertice *vtx = NULL;
    vtx = new Vertice[100000];
    int vi=0;
    
    glBegin(GL_LINES);
	for (GLfloat i = -1.5; i <= 1.5; i += 0.15) {
		glVertex3f(i, 0, 1.5); glVertex3f(i, 0, -1.5);
		glVertex3f(1.5, 0, i); glVertex3f(-1.5, 0, i);
	}
	glEnd();

	for(int i = 0; i <= end; i++){
		
		for(int x=0; x < array[i].v.size(); x++, vi++){
			vtx[vi].x = array[i].v[x].x;
			vtx[vi].y = array[i].v[x].y;
			vtx[vi].z = array[i].v[x].z;
		}

		/*Recorremos las caras de la lista*/
		list<Faces>::iterator jt;
		jt = array[i].f.begin();
		for(jt; jt!=array[i].f.end(); jt++){
			
			list<int>::iterator il;
			il = jt->intls.begin();
			glBegin(GL_LINE_LOOP);
			while(il != jt->intls.end()){
			
				glVertex3f(vtx[*il].x, vtx[*il].y, vtx[*il].z);

				il++;
			}
			glEnd();
		}
		glutSwapBuffers ();	
	}
	vtx = NULL;
	glFlush();
}

void mouse(int button, int state, int x, int y) 
{
   switch (button) {
      case GLUT_LEFT_BUTTON:
         if (state == GLUT_DOWN){
         	glutTimerFunc(refreshMillis, Timer, 0);
		 }
         break;
      case GLUT_MIDDLE_BUTTON:
         if (state == GLUT_DOWN)
            glutIdleFunc(NULL);
         break;
      default:
         break;
   }
}



